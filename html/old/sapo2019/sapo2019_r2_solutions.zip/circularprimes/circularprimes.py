# Circular primes
# Question 1, Round 2, SAPO 2019

# Check if p is prime
def is_prime(p):
    if (p < 2):
        return False
    i = 2
    while(i*i <= p):
        if (p%i == 0):
            return False
        i += 1
    return True

# Check if n is circular prime
def is_circular(n):
    if '0' in str(n):
        return False    
    k = len(str(n))
    c = n
    for i in range(k):
        if not is_prime(c):
            return False
        c = int(str(c)[1:] + str(c)[0])
    return True      

# Main input
n = int(input())
i = 1
num = 0
while(num < n):
    if (is_circular(i)):
        num += 1
    i += 1
print(i-1)
