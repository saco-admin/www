import java.util.Scanner;

public class circularprimes
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        sc.close();
        
        int v = 1;
        int cnt = 0;

        // Count up to the N-th circular prime and then output that value
        while (cnt < N)
        {
            ++v;
            if (isCPrime(v))
            {
                ++cnt;
            }
        }
        System.out.println(v);
    }

    private static boolean isCPrime(int p)
    {
        int v = p;
        int len = 1;
        while (10 * len <= p)
        {
            len *= 10;
        }

        do
        {
            // Check if the current value is prime and then move the back
            // digit to the front
            if (!isPrime(v))
            {
                return false;
            }
            int d = v % 10;
            v = (v / 10) + d * len;
        } while (v != p);

        return true;
    }

    private static boolean isPrime(int p)
    {
        // Check if the number p is prime with the root-n check
        int div = 2;
        while (div * div <= p)
        {
            if (p % div == 0)
            {
                return false;
            }
            ++div;
        }
        return true;
    }
}