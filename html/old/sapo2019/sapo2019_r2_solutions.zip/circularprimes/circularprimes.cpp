#include <bits/stdc++.h>
using namespace std;

int N;

int length(int n) {
    int t = 0, c = 1;
    while (((t*=10)+=9) <= n) c++;
    return c;
}

int pow(int a, int b) {
    if (b == 0) return 1;
    if (b == 1) return a;
    return a*pow(a, b-1);
}

bool prime(int n) {
    if (n < 2) return false;
    if ((n == 2) || (n == 3)) return true;
    if (!((n%6==1) || (n%6==5))) return false;
    for (int i = 5; i <= sqrt(n); i += 2) if (n%i==0) return false;
    return true;
}

bool cyclicprime(int n) {
    int t = n;
    int l = length(n)-1;
    do {
        if (!prime(t)) return false;
        t = (t%10)*pow(10, l)+(t/10);
    } while (t != n);
    return true;
}

int main() {
    cin >> N;
    int c = 0, i = 1;
    while ((c++) < N) while (!cyclicprime(++i)) {};
    cout << i << endl;
    return 0;
}