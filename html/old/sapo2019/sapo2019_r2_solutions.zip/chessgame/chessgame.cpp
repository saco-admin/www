#include <bits/stdc++.h>
#define MAXN 101
using namespace std;

int N;
int WR, WC, BR, BC;
bool G[MAXN][MAXN][MAXN];

inline void process(bool& b, int x, int y, int z) {
    if ((x >= 0) && (x < N) && (y >= 0) && (y < N)) b |= G[x][y][z];
}

int main() {
    cin >> N >> WC >> WR >> BC >> BR;
    WC--; WR--; BC--; BR--;
    G[BR][BC][0] = true;
    for (int r = 1; WR+r < N; r++) for (int i = 0; i < N; i++) for (int j = 0; j < N; j++) {
        process(G[i][j][r], i+1, j+2, r-1);
        process(G[i][j][r], i-1, j+2, r-1);
        process(G[i][j][r], i+1, j-2, r-1);
        process(G[i][j][r], i-1, j-2, r-1);
        process(G[i][j][r], i+2, j+1, r-1);
        process(G[i][j][r], i-2, j+1, r-1);
        process(G[i][j][r], i+2, j-1, r-1);
        process(G[i][j][r], i-2, j-1, r-1);
    }
    for (int i = 1; WR+i < N; i++) {
        if (G[WR+i][WC][i]) {
            cout << "BLACK WINS" << endl << i << endl;
            return 0;
        }
    }
    for (int i = 0; WR+i+1 < N; i++) {
        if (G[WR+i+1][WC][i]) {
            cout << "STALEMATE" << endl << i << endl;
            return 0;
        }
    }
    cout << "WHITE WINS" << endl;
    return 0;
}