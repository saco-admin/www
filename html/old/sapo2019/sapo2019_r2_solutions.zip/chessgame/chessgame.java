import java.util.ArrayList;
import java.util.Queue;
import java.util.Scanner;
import java.util.LinkedList;

public class chessgame
{
    private static int N = 0;
    private static int bx, by, wx, wy;
    private static int[][] moves = {{2, 1}, {-2, 1}, {2, -1}, {-2, -1}, {1, 2}, {-1, 2}, {1, -2}, {-1, -2}};
    private static boolean stalemate = false;
    private static int stalemateCount = 0;
    private static boolean blackWin = false;
    private static int blackWinCount = 0;

    private static int[][] lastVisit = new int[101][101];

    public static void main(String[] args)
    {
        // Take input
        Scanner sc = new Scanner(System.in);
        N = sc.nextInt();
        wx = sc.nextInt();
        wy = sc.nextInt();
        bx = sc.nextInt();
        by = sc.nextInt();
        sc.close();

        // Initialise a queue containing the state of the first black position
        Queue<ArrayList<Integer> > q = new LinkedList<>();
        ArrayList<Integer> a = new ArrayList<>();
        a.add(bx);
        a.add(by);
        a.add(0);

        q.add(a);

        // Initialise the last time each block was visited
        for (int y = 1; y <= N; ++y)
        {
            for (int x = 1; x <= N; ++x)
            {
                lastVisit[y][x] = -1;
            }
        }

        // Perform a BFS on the board
        while (q.size() != 0)
        {
            // Get the current state
            ArrayList<Integer> curr = q.remove();
            int cx = curr.get(0);
            int cy = curr.get(1);
            int d = curr.get(2);

            if (wy + d > N)
            {
                // Too many moves have been used and the pawn is off the board by now
                break;
            }
            if (cy == wy + d && cx == wx)
            {
                // The knight is currently on the pawn, so end the game
                blackWinCount = d;
                blackWin = true;
                break;
            }
            if (cy == wy + d + 1 && cx == wx)
            {
                // The knight can block the pawn, so record that a stalemate can occur
                if (!stalemate)
                {
                    stalemateCount = d;
                }
                stalemate = true;
            }

            for (int i = 0; i < 8; ++i)
            {
                // Check all extra paths and add them to the queue
                int nx = cx + moves[i][0];
                int ny = cy + moves[i][1];
                if (nx <= 0 || nx > N || ny <= 0 || ny > N)
                {
                    continue;
                }
                // Check that the new position is not already in the queue
                if (lastVisit[ny][nx] == d + 1)
                {
                    continue;
                }
                lastVisit[ny][nx] = d + 1;
                ArrayList<Integer> na = new ArrayList<>();
                na.add(nx);
                na.add(ny);
                na.add(d + 1);
                q.add(na);
            }
        }
        if (blackWin)
        {
            System.out.println("BLACK WINS");
            System.out.println(blackWinCount);
        }
        else if (stalemate)
        {
            System.out.println("STALEMATE");
            System.out.println(stalemateCount);
        }
        else
        {
            System.out.println("WHITE WINS");
        }
    }
}