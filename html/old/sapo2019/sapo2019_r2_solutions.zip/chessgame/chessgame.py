# Chess Game
# Question 4, Round 2, SAPO 2019

import queue
moves = [(-2, -1), (-2, 1), (2, -1), (2, 1),
         (-1, -2), (-1, 2), (1, -2), (1, 2)]

# Input
n = int(input())
wc, wr = map(int, input().split())
bc, br = map(int, input().split())

Q = queue.Queue()
visited = set()
stalemate = False
min_moves = 1000000

# Queue keeps tuple (moves, column, row) (keeping usual chess notation)
Q.put((0, bc, br))
while(not Q.empty()):
    cur = Q.get()
    #print(cur)

    # Check if win/stalemate
    if (cur[1] == wc) and (cur[2] == wr + cur[0]):
        # BLACK WIN (can break out)
        print("BLACK WINS")
        print(cur[0])
        break
    if (cur[1] == wc) and (cur[2] == wr + cur[0] + 1):
        # STALEMATE
        stalemate = True
        min_moves = min(min_moves, cur[0])

    # Iterate through knight's moves (allow for black to capture white on last row)
    if (cur[0] < n-wr):
        for move in moves:
            new = (cur[0]+1, cur[1]+move[0], cur[2]+move[1])

            # Check position exists and not visited
            if (1 <= new[1]) and (new[1] <= n) and (1 <= new[2]) and (new[2] <= n):
                if (new not in visited):
                    visited.add(new)
                    Q.put(new)
            
else:
    if (stalemate):
        print("STALEMATE")
        print(min_moves)
    else:
        print("WHITE WINS")

