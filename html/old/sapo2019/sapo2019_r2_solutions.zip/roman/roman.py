# Roman Numeral Addition
# Question 2, Round 2, SAPO 2019

symbols = [['', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX'],
           ['', 'X', 'XX', 'XXX', 'XL', 'L', 'LX', 'LXX', 'LXXX', 'XC'],
           ['', 'C', 'CC', 'CCC', 'CD', 'D', 'DC', 'DCC', 'DCCC', 'CM'],
           ['', 'M', 'MM', 'MMM']]

# Convert arabic to Roman
def arabic_to_roman(n):
    s = ""
    for i in range(len(str(n))):
        #print("I: ", i)
        #print("access: ", len(str(n))-i-1, int(str(n)[i]))
        s += symbols[len(str(n))-i-1][int(str(n)[i])]
    return s

# Convert Roman to arabic
def roman_to_arabic(s):
    i = 1
    while(not (arabic_to_roman(i) == s)):
        i += 1
    return i

# Main input
A = input()
B = input()
C = roman_to_arabic(A) + roman_to_arabic(B)
print(arabic_to_roman(C))
        
    

