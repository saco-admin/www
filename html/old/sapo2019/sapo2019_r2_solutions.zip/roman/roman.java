import java.util.Scanner;
import java.util.HashMap;

public class roman
{
    private static HashMap<Character, Integer> valMap = new HashMap<>();
    private static String[][] symbols = {{"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX"},
    {"", "X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC"},
    {"", "C", "CC", "CCC", "CD", "D", "DC", "DCC", "DCCC", "CM"},
    {"", "M", "MM", "MMM"}};

    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        String a = sc.next();
        String b = sc.next();
        sc.close();
        // Initialise the value of each symbol
        valMap.put('M', 1000);
        valMap.put('D', 500);
        valMap.put('C', 100);
        valMap.put('L', 50);
        valMap.put('X', 10);
        valMap.put('V', 5);
        valMap.put('I', 1);

        // First convert the strings to decimals
        // Output the roman numeral of the sun of the two decimals
        System.out.println( toRoman( toDec(a) + toDec(b) ) );
    }

    private static String toRoman(int n)
    {
        // Look up the symbol associated with each digit of the number
        String res = "";
        String s = "" + n;
        for (int i = 0; i < s.length(); ++i)
        {
            res += symbols[s.length() - i - 1][s.charAt(i)- '0'];
        }
        return res;
    }
    private static int toDec(String s)
    {
        int res = 0;

        for (int i = 0; i < s.length(); ++i)
        {
            char c = s.charAt(i);

            boolean found = false;
            for (int j = i + 1; j < s.length(); ++j)
            {
                if (valMap.get(s.charAt(j)) > valMap.get(c))
                {
                    found = true;
                    break;
                }
            }
            if (found)
            {
                // The digit is a subtractive digit sense larger value digits
                // appear later in the string
                res -= valMap.get(c);
            }
            else
            {
                // The digit is additive
                res += valMap.get(c);
            }
        }

        return res;
    }
}