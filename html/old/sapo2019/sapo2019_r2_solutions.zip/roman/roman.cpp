#include <bits/stdc++.h>
using namespace std;

string A, B;
map<char, int> FROM {{'I', 1}, {'V', 5}, {'X', 10}, {'L', 50}, {'C', 100}, {'D', 500}, {'M', 1000}};
int TOVALS[] {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
int NVALS = 13;
map<int, string> TO {{1, "I"}, {4, "IV"}, {5, "V"}, {9, "IX"}, {10, "X"}, {40, "XL"}, {50, "L"}, {90, "XC"}, {100, "C"}, {400, "CD"}, {500, "D"}, {900, "CM"}, {1000, "M"}};

string toRoman(int n) {
    string a = "";
    int i;
    while (n > 0) {
        for (i = 0; (i < NVALS) && (TOVALS[i] > n); i++) {};
        n -= TOVALS[i];
        a += TO[TOVALS[i]];
    }
    return a;
}

int fromRoman(string s) {
    int p = 1000000, a = 0;
    for (char c : s) {
        int d = FROM[c];
        a += d;
        if (d > p) a -= 2*p;
        p = d;
    }
    return a;
}

int main() {
    cin >> A >> B;
    cout << toRoman(fromRoman(A) + fromRoman(B)) << endl;
}