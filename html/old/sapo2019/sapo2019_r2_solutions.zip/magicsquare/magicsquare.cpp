#include <bits/stdc++.h>
#define MAXN 101
#define ND 1000000
using namespace std;

int N;
int G[MAXN][MAXN];
int R[MAXN], C[MAXN];

int check(int r, int c) {
    int rd = R[(r+1)%N]-R[r];
    int cd = C[(c+1)%N]-C[c];
    if (rd == cd) return rd;
    return ND;
}

int out(int* A) {
    int o1 = ND, o2 = ND, c1 = 0, c2 = 0;   
    for (int i = 0; i < N; i++) {
        if (o1 == ND) o1 = i;
        else if ((A[i] != A[o1]) && (o2 == ND)) o2 = i;
        if (A[o1] == A[i]) c1++;
        else if (A[o2] == A[i]) c2++;
        else return ND;
    }
    if (o2 == ND) return -ND;
    return (c1 == 1 ? o1 : (c2 == 1 ? o2 : ND));
}

int main() {
    cin >> N;
    for (int i = 0; i < N; i++) for (int j = 0; j < N; j++) cin >> G[i][j];
    for (int i = 0; i < N; i++) {
        int s = 0;
        for (int j = 0; j < N; j++) s += G[i][j];
        R[i] = s;
    }
    for (int i = 0; i < N; i++) {
        int s = 0;
        for (int j = 0; j < N; j++) s += G[j][i];
        C[i] = s;
    }
    if (N == 1) cout << "MAGIC" << endl;
    else if (N == 2) {
        if ((R[0]==R[1]) && (C[0]==C[1])) cout << "MAGIC" << endl;
        else if (check(0, 0) != ND) cout << "ALMOST MAGIC" << endl << "1 1 " << G[0][0]+check(0, 0) << endl;
        else if (check(0, 1) != ND) cout << "ALMOST MAGIC" << endl << "1 2 " << G[0][1]+check(0, 1) << endl;
        else if (check(1, 0) != ND) cout << "ALMOST MAGIC" << endl << "2 1 " << G[1][0]+check(1, 0) << endl;
        else if (check(1, 1) != ND) cout << "ALMOST MAGIC" << endl << "2 2 " << G[1][1]+check(1, 1) << endl;
        else cout << "NOT MAGIC" << endl;
    } else {
        int ri = out(R);
        int ci = out(C);
        if ((ri == -ND) && (ci == -ND)) cout << "MAGIC" << endl;
        else if ((ri == ND) || (ci == ND)) cout << "NOT MAGIC" << endl;
        else if (check(ri, ci) != ND) cout << "ALMOST MAGIC" << endl << (ri+1) << " " << (ci+1) << " " << G[ri][ci]+check(ri, ci) << endl;
        else cout << "NOT MAGIC" << endl;
    }
    return 0;
}