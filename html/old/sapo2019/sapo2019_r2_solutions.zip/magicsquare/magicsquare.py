# SAPO R2 2019 Q3
# Magic Squares

# Input
n = int(input())
grid = []
for i in range(n):
    grid.append(list(map(int, input().split())))

# Get distinct sums (keep in set)
rsum = []  # Row sums
csum = []  # Column sums
sums = set()
for i in range(n):
    rsum.append(sum(grid[i]))
    sums.add(rsum[i])
for i in range(n):
    s = 0
    for j in range(n):
        s += grid[j][i]
    csum.append(s)
    sums.add(csum[i])

# Output
if len(sums) == 1:
    print("MAGIC")
elif len(sums) >= 3:
    print("NOT MAGIC")
else:
    for k in list(sums):
        if (rsum.count(k) == 1) and (csum.count(k) == 1):
            rindex = rsum.index(k)
            cindex = csum.index(k)
            newval = sum(list(sums))-(2*k) + grid[rindex][cindex]
            print("ALMOST MAGIC")
            print(rindex+1, cindex+1, newval)
            break
    else:
        print("NOT MAGIC")
            
