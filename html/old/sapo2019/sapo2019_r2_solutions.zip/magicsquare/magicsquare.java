import java.util.Scanner;
import java.util.Set;
import java.util.HashSet;

public class magicsquare
{
    private static int[][] square = new int[101][101];
    private static int N = 0;
    private static int[] rowSum = new int[101];
    private static Set<Integer> rowSet = new HashSet<>();

    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        N = sc.nextInt();

        for (int i = 0; i < N; ++i)
        {
            for (int j = 0; j < N; ++j)
            {
                square[i][j] = sc.nextInt();
            }
        }
        sc.close();
        
        // Get the sums of each row and put it into an array and a set
        int v = 1000000000;
        for (int i = 0; i < N; ++i)
        {
            int s = 0;
            for (int j = 0; j < N; ++j)
            {
                s += square[i][j];
            }
            rowSum[i] = s;
            v = s;
            rowSet.add(s);
        }

        if (rowSet.size() == 1)
        {
            // All row sums are the sum, check if the column sums match
            String res = "MAGIC";
            for (int i = 0; i < N; ++i)
            {
                int s = 0;
                for (int j = 0; j < N; ++j)
                {
                    s += square[j][i];
                }
                if (s != v)
                {
                    // One of the columns does not match the row sums
                    res = "NOT MAGIC";
                    break;
                }
            }
            System.out.println(res);
        }
        else if (rowSet.size() >= 3)
        {
            // If there are more than 3 different row sums, no single value can be changed
            // to make them all equal
            System.out.println("NOT MAGIC");
        }
        else
        {
            // Variables used to determine how often each sum occurs
            int state = 0;
            int v1 = 0;
            int c1 = 0;
            int v2 = 0;
            int c2 = 0;

            for (int i = 0; i < N; ++i)
            {
                if (state == 0)
                {
                    state = 1;
                    v1 = rowSum[i];
                }
                else if (state == 1 && rowSum[i] != v1)
                {
                    state = 2;
                    v2 = rowSum[i];
                }

                // Increase the counters of the row sums
                if (rowSum[i] == v1)
                {
                    ++c1;
                }
                if (rowSum[i] == v2)
                {
                    ++c2;
                }
            }
            // Let v2 be the one that occurs fewer times
            if (c1 < c2)
            {
                int t = c1;
                int y = v1;
                c1 = c2;
                v1 = v2;
                c2 = t;
                v2 = y;
            }
            if (c2 != 1)
            {
                // There isn't a single row that can be changed
                System.out.println("NOT MAGIC");
            }
            else
            {
                // Determine which cell to change by checking which column sum
                // matches the row sum that needs to change
                int y = 0;
                for (int i = 0; i < N; ++i)
                {
                    if (rowSum[i] == v2)
                    {
                        y = i;
                        break;
                    }
                }
                int x = -1;
                for (int i = 0; i < N; ++i)
                {
                    int s = 0;
                    for (int j = 0; j < N; ++j)
                    {
                        s += square[j][i];
                    }
                    if (s == v2)
                    {
                        x = i;
                        break;
                    }
                }
                if (x == -1)
                {
                    // No column matches the row sum
                    System.out.println("NOT MAGIC");
                }
                else
                {
                    boolean found = false;
                    // Set the new value in the square
                    square[y][x] += v1 - v2;

                    // Check that all of the column sums match the row sums
                    for (int i = 0; i < N; ++i)
                    {
                        int s = 0;
                        for (int j = 0; j < N; ++j)
                        {
                            s += square[j][i];
                        }
                        if (s != v1)
                        {
                            found = true;
                            break;
                        }
                    }
                    if (found)
                    {
                        // Not a magic square
                        System.out.println("NOT MAGIC");
                    }
                    else
                    {
                        // Can be turned into a magic square
                        System.out.println("ALMOST MAGIC");
                        System.out.println((y + 1) + " " + (x + 1) + " " + square[y][x]);
                    }
                }
            }
        }

    }
}